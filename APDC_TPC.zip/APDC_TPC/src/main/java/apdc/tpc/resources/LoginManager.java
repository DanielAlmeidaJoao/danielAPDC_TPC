package apdc.tpc.resources;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.cloud.datastore.Datastore;
import com.google.cloud.datastore.DatastoreOptions;
import com.google.gson.Gson;
import com.google.cloud.datastore.Entity;

import apdc.tpc.utils.AdditionalAttributes;
import apdc.tpc.utils.AuthToken;
import apdc.tpc.utils.AuthenticateUser;
import apdc.tpc.utils.ChangeOtherUser;
import apdc.tpc.utils.LoggedObject;
import apdc.tpc.utils.LoginData;
import apdc.tpc.utils.RegisterData;
import apdc.tpc.utils.StorageMethods;
import apdc.tpc.utils.UserInfo;

@Path("/login")
@Produces(MediaType.APPLICATION_JSON +";charset=utf-8")
public class LoginManager {
	@Context private HttpServletRequest request;
	public static final Datastore datastore =	DatastoreOptions.getDefaultInstance().getService();

	//AUTHOR: DANIEL JOAO, COPYING IT WITHOUT MY CONSENT IS A CRIME, LEADING UP TO 7 YEARS IN JAIL
	private static final Map<String,AuthToken> tokens = new HashMap<>();
	
	private final Gson g = new Gson();

	@GET
	@Path("/{username}")
	public Response getUser(@PathParam("username") String username ) {
		boolean rs;
		if(username.trim().equals("daniel")) {
			rs = true;
		}else {
			rs= false;
		}
		return Response.ok().entity(g.toJson(rs)).build();
	}
	private String validToken(String token) {
		//long now;
		//AuthToken tk = tokens.get(token);
		return AuthenticateUser.validateToken(datastore,token);
	}
	private String registerToken(String email) {
		String token=null;
		AuthToken tk = new AuthToken(email);
		tokens.put(tk.tokenID,tk);
		if(AuthenticateUser.insertToken(datastore,tk)>0) {
			token=tk.tokenID;
		}
		return token;
	}
	@POST
	@Path("/op1")
	@Consumes(MediaType.APPLICATION_JSON +";charset=utf-8")
	@Produces(MediaType.APPLICATION_JSON +";charset=utf-8")
	public Response doRegister(RegisterData data) {
		System.out.println("USER REGISTERED! pp "+data.getEmail());
		Response res=null;
		LoggedObject lo = StorageMethods.addUser(datastore,data,g);
		if(lo.getStatus().equals("1")) {
			String token=registerToken(lo.getEmail());
			if(token!=null) {
				lo.setStatus("1");
				lo.setToken(token);
			}else {
				lo.setStatus("3");
			}
		}
		
		res= Response.ok().entity(g.toJson(lo)).build();
		return res;
	}
	
	@POST
	@Path("/op2")
	@Consumes(MediaType.APPLICATION_JSON +";charset=utf-8")
	@Produces(MediaType.APPLICATION_JSON +";charset=utf-8")
	public Response doLogin(LoginData data) {
		String res=null;
		LoggedObject lo = new LoggedObject();
		try {
			Entity user = StorageMethods.getUser(datastore,data);
			if(user==null) {
				lo.setStatus("0");
			}else{
				//AuthToken at = new AuthToken(user.getString("email"));
				lo.setEmail(data.getEmail());
				lo.setName(user.getString("name"));
				lo.setToken(registerToken(lo.getEmail()));
				if(lo.getToken()==null) {
					lo.setStatus("2");
				}else {
					lo.setStatus("1");
					lo.setGbo("GBO".equals(user.getString("role")));
				}
				AdditionalAttributes ad= StorageMethods.getAdditionalAttributes(datastore,data.getEmail());
				if(ad==null) {
					lo.setAdditionalAttributes("0");
				}else {
					lo.setAdditionalAttributes(g.toJson(ad));
				}
			}
		}catch(Exception e) {
			lo.setStatus("-1");
		}
		res= g.toJson(lo);
		return  Response.ok().entity(res).build();
	}
	@POST
	@Path("/op3")
	@Consumes(MediaType.APPLICATION_JSON +";charset=utf-8")
	@Produces(MediaType.TEXT_PLAIN +";charset=utf-8")
	public Response doUpdateAdditionalInfos(AdditionalAttributes ads) {
		if(request!=null) {
			System.out.println();
		}else {
			System.out.println();
		}
		String email = AuthenticateUser.validateToken(datastore,ads.getEmail());
		String result = "-2";
		
		ads.setEmail(validToken(ads.getEmail()));
		if(email!=null) {
			ads.setEmail(email);
			result=""+StorageMethods.addUserAdditionalInformation(datastore, ads);
		}else {
			result="TOKEN NOT FOUND";
		}
		return Response.ok().entity(result).build();
	}

	@GET
	@Path("/op7/{token}")
	@Produces(MediaType.TEXT_PLAIN +";charset=utf-8")
	public Response doLogout(@PathParam("token") String token) {
		int result = AuthenticateUser.removeToken(datastore,token);
		return Response.ok().entity(result).build();
	}
	@POST
	@Path("/op8")
	@Consumes(MediaType.APPLICATION_JSON +";charset=utf-8")
	@Produces(MediaType.APPLICATION_JSON +";charset=utf-8")
	public Response doRemove(LoginData data) {
		String tk = AuthenticateUser.validateToken(datastore,data.getEmail());
		String res="";
		if(tk==null) {
			res="SESSION EXPIRED!";
		}else {
			data.setEmail(tk);
			if (StorageMethods.removeUser(datastore, data)>0) {
				AuthenticateUser.removeToken(datastore,tk);
				res="REMOVED WITH SUCCESS!";
			}else {
				res="THERE WAS AN ERROR!";
			}
		}
		return Response.ok().entity(res).build();
	}
	@POST
	@Path("/op9")
	@Consumes(MediaType.APPLICATION_JSON +";charset=utf-8")
	@Produces(MediaType.APPLICATION_JSON +";charset=utf-8")
	public Response doSpy(LoginData data) {
		//email -> token
		//password -> other user email
		UserInfo u = StorageMethods.getOtherUser(datastore, data);
		return Response.ok().entity(g.toJson(u)).build();
	}
	
	@POST
	@Path("/op10")
	@Consumes(MediaType.APPLICATION_JSON +";charset=utf-8")
	@Produces(MediaType.APPLICATION_JSON +";charset=utf-8")
	public Response blockOtherUsers(ChangeOtherUser data) {
		//data.email -> token
		//data.password -> password
		//data.name -> the email of another user
		String u = StorageMethods.disableUser(datastore,data);
		if(u.equals("2")) {
			AuthenticateUser.removeTokens(datastore,data.getEmail());
		}
		return Response.ok().entity(g.toJson(u)).build();
	}
	@POST
	@Path("/op11")
	@Consumes(MediaType.APPLICATION_JSON +";charset=utf-8")
	@Produces(MediaType.APPLICATION_JSON +";charset=utf-8")
	public Response doChangePassword(RegisterData data) {
		/**
		 * name: oldPass,
	       password: newPass,
	       email: token,
		 */
		String email = validToken(data.getEmail());
		if(email!=null) {
			email = StorageMethods.updatePassword(datastore, email,data.getPassword(),data.getName()); //result
		}else {
			email="-1";
		}
		return Response.ok().entity(email).build();
	}
}
